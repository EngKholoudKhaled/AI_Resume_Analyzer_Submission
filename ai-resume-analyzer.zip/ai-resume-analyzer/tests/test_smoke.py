"""End-to-end smoke test: python -m pytest tests  (or python tests/test_smoke.py)"""
import io, os, sys, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "test.db")
os.environ.pop("ANTHROPIC_API_KEY", None)
from fastapi.testclient import TestClient
from backend.main import app

RESUME = """Ahmed Hassan
ahmed@example.com | +20 100 123 4567 | github.com/ahmed
Summary
Backend developer with 4 years of experience building APIs.
Skills: Python, FastAPI, SQL, PostgreSQL, Docker, Git, REST API, teamwork, communication
Experience
Software Engineer, Nile Tech 2021 - 2024
- Reduced API latency by 35% and served 20,000 users. Collaborated with a team of 5.
Education
B.Sc. Computer Science, Mansoura University, 2020"""


def make_docx(text):
    import docx
    d = docx.Document()
    for line in text.splitlines():
        d.add_paragraph(line)
    b = io.BytesIO(); d.save(b); return b.getvalue()


def test_flow():
    with TestClient(app) as c:
        assert c.get("/api/health").status_code == 200
        assert c.post("/api/auth/register", json={"email": "bad", "password": "short"}).status_code == 422
        r = c.post("/api/auth/register", json={"email": "a@b.com", "password": "password123"}); assert r.status_code == 201
        assert c.post("/api/auth/register", json={"email": "a@b.com", "password": "password123"}).status_code == 409
        assert c.post("/api/auth/login", json={"email": "a@b.com", "password": "wrongpass1"}).status_code == 401
        H = {"Authorization": "Bearer " + c.post("/api/auth/login", json={"email": "a@b.com", "password": "password123"}).json()["token"]}
        assert c.get("/api/jobs").status_code == 401
        # invalid uploads
        assert c.post("/api/resumes", files={"file": ("x.txt", b"hello", "text/plain")}, headers=H).status_code == 415
        assert c.post("/api/resumes", files={"file": ("x.pdf", b"notapdf", "application/pdf")}, headers=H).status_code == 422
        up = c.post("/api/resumes", files={"file": ("cv.docx", make_docx(RESUME), "application/octet-stream")}, headers=H)
        assert up.status_code == 201, up.text
        a = up.json()["analysis"]; rid = up.json()["id"]
        assert "python" in a["skills"]["technical"] and a["experience"]["years"] >= 3, a
        assert a["contact"]["name"] == "Ahmed Hassan"
        recs = c.get(f"/api/resumes/{rid}/recommendations", headers=H).json()
        assert recs[0]["job"]["title"] == "Backend Python Developer", [r["job"]["title"] for r in recs]
        imp = c.get(f"/api/resumes/{rid}/improvements?job_id={recs[1]['job']['id']}", headers=H).json()
        assert "missing_skills" in imp and imp["writing_guidelines"] is not None
        # jobs CRUD + search
        job = c.post("/api/jobs", headers=H, json={"title": "Rust Engineer", "company": "X", "description": "Build systems with Python and Docker daily."})
        assert job.status_code == 201 and "docker" in job.json()["skills"]
        jid = job.json()["id"]
        assert c.put(f"/api/jobs/{jid}", headers=H, json={"title": "Rust Eng", "company": "X", "description": "Updated description for the role here."}).status_code == 200
        assert len(c.get("/api/jobs?skill=docker", headers=H).json()) >= 2
        assert c.get("/api/jobs?q=nothingmatches123", headers=H).json() == []
        assert c.delete(f"/api/jobs/{jid}", headers=H).status_code == 204
        assert c.get(f"/api/jobs/{jid}", headers=H).status_code == 404
        # advisor (RAG)
        ch = c.post("/api/advisor/chat", headers=H, json={"message": "Which certifications should I get for Kubernetes?"}).json()
        assert ch["sources"] and "kubernetes" in ch["answer"].lower(), ch
        assert len(c.get("/api/advisor/history", headers=H).json()) == 2
        assert c.post("/api/auth/logout", headers=H).status_code == 204
        assert c.get("/api/resumes", headers=H).status_code == 401
    print("ALL TESTS PASSED")


def test_non_technical_cv():
    from backend.agents import resume_agent
    a = resume_agent.analyze("""Jane Doe
jane@example.com | 0100 000 0000
Professional Summary
Student with over three years of experience in HR and administration.
Experience
Executive Assistant | Media Co Jun 2022 - Dec 2023
Operations Intern | Data Co Jun 2022 - Dec 2023
Administrative Coordinator | Agency Jan 2024 - Oct 2025
EDUCATION
B.Sc. Computer Science | Benha University
SKILLS
PowerPoint, Excel, Scratch, Notion, Trello, recruitment, teaching, programming""")
    tech = a["skills"]["technical"]
    assert {"powerpoint", "excel", "scratch", "hr", "recruitment", "administrative", "teaching"} <= set(tech), tech
    assert 3.0 <= a["experience"]["years"] <= 4.0, a["experience"]   # overlaps counted once
    assert a["education"][0].startswith("B.Sc."), a["education"]
    print("NON-TECHNICAL CV TEST PASSED")


if __name__ == "__main__":
    test_flow()
    test_non_technical_cv()
