/* AI Resume Analyzer - vanilla JS SPA */
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const chips = (a, cls = "") => (a || []).map(x => `<span class="chip ${cls}">${esc(x)}</span>`).join("") || '<span class="muted">none</span>';
const list = a => (a && a.length) ? `<ul>${a.map(x => `<li>${esc(x)}</li>`).join("")}</ul>` : '<p class="muted">Nothing to show.</p>';
let token = localStorage.getItem("token"), authMode = "login", resumes = [], jobsCache = [];

function toast(msg, ok = false) {
  const t = $("toast"); t.textContent = msg; t.className = ok ? "ok" : ""; t.hidden = false;
  clearTimeout(toast.t); toast.t = setTimeout(() => t.hidden = true, 4500);
}

async function api(path, opts = {}) {
  const headers = { ...(opts.headers || {}) };
  if (token) headers.Authorization = "Bearer " + token;
  let body = opts.body;
  if (body && !(body instanceof FormData)) { headers["Content-Type"] = "application/json"; body = JSON.stringify(body); }
  const r = await fetch("/api" + path, { ...opts, headers, body });
  let data = null; try { data = await r.json(); } catch (e) { /* 204 */ }
  if (!r.ok) {
    if (r.status === 401 && token) showAuth();
    throw new Error(data && data.detail ? (typeof data.detail === "string" ? data.detail : JSON.stringify(data.detail)) : `Request failed (${r.status})`);
  }
  return data;
}
const guard = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message); } };
const busy = (btn, on) => { btn.disabled = on; };

/* ---------- auth ---------- */
document.querySelectorAll("[data-auth]").forEach(b => b.onclick = () => {
  authMode = b.dataset.auth; $("authBtn").textContent = b.textContent;
  document.querySelectorAll("[data-auth]").forEach(x => x.classList.toggle("active", x === b));
});
$("authBtn").onclick = guard(async () => {
  const email = $("email").value.trim(), password = $("password").value;
  if (!email || password.length < 8) return toast("Enter a valid email and a password of at least 8 characters.");
  const d = await api("/auth/" + authMode, { method: "POST", body: { email, password } });
  token = d.token; localStorage.setItem("token", token); $("useremail").textContent = d.email; localStorage.setItem("email", d.email);
  $("password").value = ""; await showApp();
});
$("logoutBtn").onclick = async () => { try { await api("/auth/logout", { method: "POST" }); } catch (e) { } showAuth(); };
function showAuth() {
  token = null; localStorage.removeItem("token");
  $("authView").hidden = false; $("appView").hidden = true; $("userbox").hidden = true;
}
async function showApp() {
  $("authView").hidden = true; $("appView").hidden = false; $("userbox").hidden = false;
  $("useremail").textContent = localStorage.getItem("email") || "";
  await Promise.all([loadResumes(), loadJobs(), loadHistory()]);
}

/* ---------- tabs ---------- */
document.querySelectorAll("#nav button").forEach(b => b.onclick = () => {
  document.querySelectorAll("#nav button").forEach(x => x.classList.toggle("active", x === b));
  document.querySelectorAll(".tab").forEach(t => t.hidden = t.id !== "tab-" + b.dataset.tab);
  if (b.dataset.tab === "recs") guard(loadRecs)();
});

/* ---------- resumes ---------- */
const currentResume = () => $("resumeSelect").value;
async function loadResumes(selectId) {
  resumes = await api("/resumes");
  $("resumeSelect").innerHTML = resumes.map(r => `<option value="${r.id}">${esc(r.filename)} (#${r.id})</option>`).join("") || '<option value="">No resumes yet</option>';
  if (selectId) $("resumeSelect").value = selectId;
  if (currentResume()) await loadAnalysis(); else $("analysis").innerHTML = "";
}
$("resumeSelect").onchange = guard(loadAnalysis);
$("uploadBtn").onclick = guard(async () => {
  const f = $("file").files[0];
  if (!f) return toast("Choose a PDF or DOCX file first.");
  if (!/\.(pdf|docx)$/i.test(f.name)) return toast("Only PDF or DOCX files are supported.");
  if (f.size > 5 * 1024 * 1024) return toast("File is too large (max 5 MB).");
  const fd = new FormData(); fd.append("file", f);
  busy($("uploadBtn"), true); $("analysis").innerHTML = '<p class="loading">Analyzing your resume...</p>';
  try { const d = await api("/resumes", { method: "POST", body: fd }); toast("Resume analyzed.", true); $("file").value = ""; await loadResumes(d.id); }
  finally { busy($("uploadBtn"), false); }
});
$("delResume").onclick = guard(async () => {
  if (!currentResume() || !confirm("Delete this resume and its analysis?")) return;
  await api("/resumes/" + currentResume(), { method: "DELETE" }); await loadResumes();
});
async function loadAnalysis() {
  if (!currentResume()) return;
  const { analysis: a } = await api(`/resumes/${currentResume()}/analysis`), c = a.contact;
  $("analysis").innerHTML = `
  <div class="card"><h2>Summary</h2><p>${esc(a.summary)}</p>
    <p class="muted">${esc(c.name || "Name not detected")} &middot; ${esc(c.email || "no email")} &middot; ${esc(c.phone || "no phone")}</p></div>
  <div class="card"><h2>Skills</h2><h3>Technical</h3>${chips(a.skills.technical)}<h3>Soft</h3>${chips(a.skills.soft, "soft")}</div>
  <div class="card"><h2>Experience: ${a.experience.years} year(s) &middot; ${esc(a.experience.level)}</h2>${list(a.experience.entries)}
    <h2>Education</h2>${list(a.education)}</div>
  <div class="card"><h2>Weaknesses</h2>${list(a.weaknesses)}<h2>Suggested improvements</h2>${list(a.improvements)}</div>`;
}

/* ---------- recommendations ---------- */
async function loadRecs() {
  if (!currentResume()) { $("recs").innerHTML = "<p>Upload a resume first.</p>"; return; }
  $("recs").innerHTML = '<p class="loading">Matching your resume with jobs...</p>';
  const recs = await api(`/resumes/${currentResume()}/recommendations?limit=10`);
  $("recs").innerHTML = "<h2>Recommended jobs</h2>" + recs.map(r => `
    <div class="job"><div class="row"><div style="flex:1"><b>${esc(r.job.title)}</b> - ${esc(r.job.company)}
      <div class="muted">${esc(r.job.location)} &middot; ${esc(r.job.job_type)}</div></div><div class="score">${r.score}%</div></div>
      <div class="bar"><div style="width:${r.score}%"></div></div>
      <p>${esc(r.explanation)}</p>
      <div>Matched: ${chips(r.matched_skills, "ok")}</div><div>Missing: ${chips(r.missing_skills, "bad")}</div>
      <div class="muted">Skill overlap ${r.skill_overlap}% &middot; Semantic similarity ${r.semantic_similarity}%</div></div>`).join("");
}

/* ---------- improvements ---------- */
$("improveBtn").onclick = guard(async () => {
  if (!currentResume()) return toast("Upload a resume first.");
  const jid = $("targetJob").value, box = $("improve");
  box.innerHTML = '<p class="loading">Building your plan...</p>';
  const p = await api(`/resumes/${currentResume()}/improvements` + (jid ? `?job_id=${jid}` : ""));
  box.innerHTML = `
  <div class="card"><h2>Target: ${p.target_job ? esc(p.target_job.title + " at " + p.target_job.company) : "n/a"}</h2>
    <h3>Missing skills</h3>${chips(p.missing_skills, "bad")}
    <h3>Recommended certifications</h3>${list(p.certifications.map(x => `${x.skill}: ${x.certification}`))}
    <h3>Learning resources</h3>${list(p.learning_resources.map(x => `${x.skill}: ${x.resource}`))}</div>
  <div class="card"><h3>Resume weaknesses</h3>${list(p.weaknesses)}<h3>Improvements</h3>${list(p.improvements)}
    <h3>Writing guidelines</h3>${list(p.writing_guidelines.map(g => `${g.title}: ${g.text}`))}</div>`;
});

/* ---------- jobs ---------- */
async function loadJobs(query = "") {
  jobsCache = await api("/jobs" + query);
  if (!query) $("targetJob").innerHTML = '<option value="">Best matching job</option>' + jobsCache.map(j => `<option value="${j.id}">${esc(j.title)} - ${esc(j.company)}</option>`).join("");
  $("jobList").innerHTML = jobsCache.map(j => `
    <div class="card"><div class="row"><div style="flex:1"><b>${esc(j.title)}</b> - ${esc(j.company)}
      <div class="muted">${esc(j.location)} &middot; ${esc(j.job_type)}</div></div>
      <button class="ghost" onclick="editJob(${j.id})">Edit</button><button class="ghost danger" onclick="deleteJob(${j.id})">Delete</button></div>
      <p>${esc(j.description)}</p>${chips(j.skills)}</div>`).join("") || '<div class="card">No jobs found.</div>';
}
const searchQuery = () => {
  const p = new URLSearchParams();
  [["q", "sq"], ["skill", "sskill"], ["location", "sloc"], ["type", "stype"]].forEach(([k, id]) => $(id).value.trim() && p.set(k, $(id).value.trim()));
  return p.toString() ? "?" + p : "";
};
$("searchBtn").onclick = guard(async () => { const q = searchQuery(); await loadJobs(q); });
$("clearBtn").onclick = guard(async () => { ["sq", "sskill", "sloc", "stype"].forEach(i => $(i).value = ""); await loadJobs(); });
const resetJobForm = () => { ["jid", "jtitle", "jcompany", "jloc", "jdesc", "jskills"].forEach(i => $(i).value = ""); $("jtype").value = "Full-time"; $("jobFormTitle").textContent = "Add a job"; $("cancelJob").hidden = true; };
$("cancelJob").onclick = resetJobForm;
$("saveJob").onclick = guard(async () => {
  const body = { title: $("jtitle").value.trim(), company: $("jcompany").value.trim(), location: $("jloc").value.trim(),
    job_type: $("jtype").value.trim() || "Full-time", description: $("jdesc").value.trim(),
    skills: $("jskills").value.split(",").map(s => s.trim()).filter(Boolean) };
  if (!body.title || !body.company) return toast("Title and company are required.");
  if (body.description.length < 20) return toast("Description must be at least 20 characters.");
  const id = $("jid").value;
  await api("/jobs" + (id ? "/" + id : ""), { method: id ? "PUT" : "POST", body });
  toast(id ? "Job updated." : "Job added.", true); resetJobForm(); await loadJobs();
});
window.editJob = id => {
  const j = jobsCache.find(x => x.id === id); if (!j) return;
  $("jid").value = j.id; $("jtitle").value = j.title; $("jcompany").value = j.company; $("jloc").value = j.location;
  $("jtype").value = j.job_type; $("jdesc").value = j.description; $("jskills").value = j.skills.join(", ");
  $("jobFormTitle").textContent = "Edit job #" + id; $("cancelJob").hidden = false; window.scrollTo({ top: 0, behavior: "smooth" });
};
window.deleteJob = guard(async id => { if (!confirm("Delete this job?")) return; await api("/jobs/" + id, { method: "DELETE" }); await loadJobs(); });

/* ---------- advisor ---------- */
const addMsg = (role, text) => { const d = document.createElement("div"); d.className = "msg " + role; d.textContent = text; $("chat").appendChild(d); $("chat").scrollTop = 1e9; return d; };
async function loadHistory() { $("chat").innerHTML = ""; (await api("/advisor/history")).forEach(m => addMsg(m.role, m.content)); }
const sendChat = guard(async () => {
  const message = $("chatInput").value.trim(); if (message.length < 2) return;
  $("chatInput").value = ""; addMsg("user", message); const wait = addMsg("assistant", "Thinking..."); busy($("chatBtn"), true);
  try {
    const d = await api("/advisor/chat", { method: "POST", body: { message, resume_id: currentResume() ? +currentResume() : null } });
    wait.textContent = d.answer + (d.sources.length ? "\n\nSources: " + d.sources.map(s => s.title).join(", ") : "");
  } catch (e) { wait.remove(); throw e; } finally { busy($("chatBtn"), false); }
});
$("chatBtn").onclick = sendChat;
$("chatInput").addEventListener("keydown", e => { if (e.key === "Enter") sendChat(); });

/* ---------- boot ---------- */
if (token) showApp().catch(() => showAuth());
