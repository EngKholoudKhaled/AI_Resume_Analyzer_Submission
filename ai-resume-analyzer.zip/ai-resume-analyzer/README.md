# AI Resume Analyzer

Web app that analyzes resumes (PDF/DOCX), recommends jobs, and gives career advice using three AI agents and a RAG pipeline.
**Stack:** Python + FastAPI, SQLite, HTML/CSS/vanilla JS (no frameworks).

## Quick start
```bash
cd backend
pip install -r requirements.txt
cd ..
uvicorn backend.main:app --reload        # open http://127.0.0.1:8000
```
- Interactive API docs (Swagger): http://127.0.0.1:8000/docs
- Tests: `python tests/test_smoke.py`
- **Optional LLM mode:** `export ANTHROPIC_API_KEY=sk-ant-...` (and optionally `ANTHROPIC_MODEL`). Without a key the app runs fully offline (rule-based analysis + TF-IDF retrieval). `GET /api/health` shows the active mode.

## Project structure
```
backend/
  main.py            app, error handler, static frontend
  database.py        schema, seeding, helpers
  auth.py            PBKDF2 hashing, DB-backed bearer sessions (24h)
  routers/           auth, resumes, jobs, advisor
  services/          parser (PDF/DOCX), skills dictionary, rag (TF-IDF), llm (optional)
  agents/            resume_agent, matching_agent, advisor_agent
  knowledge_base/    seed_data.py (skills, roadmaps, resume guidelines, sample jobs)
frontend/            index.html, style.css, app.js
tests/test_smoke.py  end-to-end test
```

## AI design
| Agent | Role |
|---|---|
| Resume Analyzer | Extracts contact, technical/soft skills, education, experience years/level, weaknesses, improvements, summary (LLM summary when a key is set). |
| Job Matching | `score = 0.6 * skill_overlap + 0.4 * semantic_similarity` (TF-IDF cosine, rescaled x2, capped at 1). Returns matched/missing skills and an explanation. |
| Career Advisor | Retrieves top-k chunks from the knowledge base, then answers from them (LLM if available, otherwise composes from retrieved chunks). Also builds the improvement plan (certifications and resources per missing skill). |

**RAG pipeline:** knowledge base (skills, roadmaps, guidelines, learning resources, plus all job descriptions) -> chunk -> TF-IDF vectors -> cosine top-k -> injected into the prompt. The index rebuilds automatically when jobs change.

## ER diagram
```mermaid
erDiagram
    USERS ||--o{ SESSIONS : has
    USERS ||--o{ RESUMES : uploads
    RESUMES ||--o| ANALYSES : has
    RESUMES ||--o{ RECOMMENDATIONS : generates
    JOBS ||--o{ RECOMMENDATIONS : matched_in
    JOBS ||--o{ JOB_SKILLS : requires
    SKILLS ||--o{ JOB_SKILLS : listed_in
    USERS ||--o{ CHAT_MESSAGES : asks
    USERS { int id PK; string email UK; string password_hash; datetime created_at }
    SESSIONS { string token PK; int user_id FK; float created }
    RESUMES { int id PK; int user_id FK; string filename; text raw_text; datetime uploaded_at }
    ANALYSES { int id PK; int resume_id FK; json contact; json skills; json education; json experience; text summary; json weaknesses; json improvements }
    JOBS { int id PK; string title; string company; string location; string job_type; text description }
    SKILLS { int id PK; string name UK; string category }
    JOB_SKILLS { int job_id FK; int skill_id FK }
    RECOMMENDATIONS { int id PK; int resume_id FK; int job_id FK; float score; text explanation }
    KB_DOCUMENTS { int id PK; string category; string title; text content }
    CHAT_MESSAGES { int id PK; int user_id FK; string role; text content; datetime created_at }
```
`KB_DOCUMENTS` is the RAG knowledge base (chunks and vectors are built in memory at startup).

## REST API
All endpoints except register/login require `Authorization: Bearer <token>`. Errors return `{"detail": "message"}`.

| Method & path | Description | Success | Errors |
|---|---|---|---|
| POST `/api/auth/register` `{email,password>=8}` | Create account, returns `{token,email}` | 201 | 409 exists, 422 invalid |
| POST `/api/auth/login` | Login, returns token | 200 | 401 bad credentials |
| POST `/api/auth/logout` | Invalidate token | 204 | 401 |
| GET `/api/auth/me` | Current user | 200 | 401 |
| POST `/api/resumes` (multipart `file`) | Upload PDF/DOCX, parse + analyze | 201 | 413 >5MB, 415 wrong type, 422 unreadable/empty/scanned |
| GET `/api/resumes` | List own resumes | 200 | |
| DELETE `/api/resumes/{id}` | Delete resume | 204 | 404 |
| GET `/api/resumes/{id}/analysis` | Skills, education, experience, summary, weaknesses | 200 | 404 |
| GET `/api/resumes/{id}/recommendations?limit=10` | Ranked jobs with score, matched/missing skills, explanation | 200 | 404 |
| GET `/api/resumes/{id}/improvements?job_id=` | Missing skills, weaknesses, certifications, resources, guidelines (defaults to best-matching job) | 200 | 404 |
| GET `/api/jobs?q=&skill=&location=&type=&company=&limit=&offset=` | Search / list jobs | 200 | |
| GET `/api/jobs/{id}` | View job | 200 | 404 |
| POST `/api/jobs` `{title,company,location,job_type,description,skills[]}` | Add job (skills auto-detected if omitted) | 201 | 422 |
| PUT `/api/jobs/{id}` | Edit job | 200 | 404, 422 |
| DELETE `/api/jobs/{id}` | Delete job | 204 | 404 |
| POST `/api/advisor/chat` `{message,resume_id?}` | RAG-grounded career answer with sources | 200 | 422 |
| GET `/api/advisor/history` | Chat history | 200 | |
| GET `/api/health` | Status and AI mode | 200 | |

## Demo script
1. Register and log in. 2. Upload a resume, then review the summary, skills and weaknesses. 3. **Job Matches**: scores and explanations. 4. **Improve**: pick a target job for missing skills, certifications and resources. 5. **Jobs**: search by skill, add, edit and delete a job. 6. **Career Advisor**: ask "Which certifications should I get for Kubernetes?" and see the sources.

## Notes / limitations
- Skill extraction is dictionary-based (extend `services/skills.py`; it also covers office, HR, administration and teaching skills, not only programming); scanned image PDFs are rejected (no OCR).
- Sessions are server-side tokens; use HTTPS and a real secret store in production.
- Job data is shared among all users (any logged-in user may edit); add roles for production.
