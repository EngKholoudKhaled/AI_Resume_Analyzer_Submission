"""SQLite connection, schema and seeding."""
import os, sqlite3

DB_PATH = os.getenv("DB_PATH", os.path.join(os.path.dirname(__file__), "app.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS resumes(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  filename TEXT NOT NULL, raw_text TEXT NOT NULL, uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS analyses(
  id INTEGER PRIMARY KEY AUTOINCREMENT, resume_id INTEGER UNIQUE NOT NULL REFERENCES resumes(id) ON DELETE CASCADE,
  contact TEXT, skills TEXT, education TEXT, experience TEXT, summary TEXT, weaknesses TEXT, improvements TEXT);
CREATE TABLE IF NOT EXISTS skills(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, category TEXT DEFAULT 'technical');
CREATE TABLE IF NOT EXISTS jobs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, company TEXT NOT NULL,
  location TEXT DEFAULT '', job_type TEXT DEFAULT 'Full-time', description TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS job_skills(
  job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  skill_id INTEGER NOT NULL REFERENCES skills(id) ON DELETE CASCADE, PRIMARY KEY(job_id, skill_id));
CREATE TABLE IF NOT EXISTS recommendations(
  id INTEGER PRIMARY KEY AUTOINCREMENT, resume_id INTEGER NOT NULL REFERENCES resumes(id) ON DELETE CASCADE,
  job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE, score REAL, explanation TEXT);
CREATE TABLE IF NOT EXISTS kb_documents(
  id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS chat_messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
"""


def connect():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def get_db():
    conn = connect()
    try:
        yield conn
    finally:
        conn.close()


def get_or_create_skill(conn, name, category="technical"):
    name = name.strip().lower()
    row = conn.execute("SELECT id FROM skills WHERE name=?", (name,)).fetchone()
    if row:
        return row["id"]
    return conn.execute("INSERT INTO skills(name,category) VALUES(?,?)", (name, category)).lastrowid


def set_job_skills(conn, job_id, skills):
    conn.execute("DELETE FROM job_skills WHERE job_id=?", (job_id,))
    for s in dict.fromkeys(x.strip().lower() for x in skills if x.strip()):
        conn.execute("INSERT OR IGNORE INTO job_skills VALUES(?,?)", (job_id, get_or_create_skill(conn, s)))


def job_dict(conn, row):
    d = dict(row)
    d["skills"] = [r["name"] for r in conn.execute(
        "SELECT s.name FROM job_skills js JOIN skills s ON s.id=js.skill_id WHERE js.job_id=? ORDER BY s.name",
        (row["id"],))]
    return d


def init_db():
    from .knowledge_base.seed_data import JOBS, build_kb_documents
    from .services.skills import TECH, SOFT
    conn = connect()
    conn.executescript(SCHEMA)
    for s in TECH:
        get_or_create_skill(conn, s, "technical")
    for s in SOFT:
        get_or_create_skill(conn, s, "soft")
    have_docs = {(r[0], r[1]) for r in conn.execute("SELECT category,title FROM kb_documents")}
    new_docs = [d for d in build_kb_documents() if (d[0], d[1]) not in have_docs]
    if new_docs:  # also adds newly introduced knowledge to an existing database
        conn.executemany("INSERT INTO kb_documents(category,title,content) VALUES(?,?,?)", new_docs)
    if not conn.execute("SELECT 1 FROM jobs LIMIT 1").fetchone():
        for j in JOBS:
            jid = conn.execute("INSERT INTO jobs(title,company,location,job_type,description) VALUES(?,?,?,?,?)",
                               (j["title"], j["company"], j["location"], j["type"], j["description"])).lastrowid
            set_job_skills(conn, jid, j["skills"])
    conn.commit()
    conn.close()
