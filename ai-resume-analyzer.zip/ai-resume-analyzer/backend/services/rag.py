"""Pure-Python TF-IDF retrieval (RAG retriever) over the knowledge base + jobs."""
import math, re
from collections import Counter

STOP = set("a an the and or of to in for on with is are be as at by it this that from your you i my what how do can".split())


def tokens(text):
    return [t.rstrip(".") for t in re.findall(r"[a-z0-9][a-z0-9+#.]*", text.lower()) if t.rstrip(".") not in STOP]


class Tfidf:
    def __init__(self, texts):
        toks = [tokens(t) for t in texts]
        n, df = len(toks), Counter()
        for t in toks:
            df.update(set(t))
        self.idf = {w: math.log((1 + n) / (1 + c)) + 1 for w, c in df.items()}
        self.vecs = [self._vec(t) for t in toks]

    def _vec(self, toks):
        v = {w: (1 + math.log(c)) * self.idf.get(w, 1.0) for w, c in Counter(toks).items()}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {w: x / norm for w, x in v.items()}

    def vec(self, text):
        return self._vec(tokens(text))


def cosine(a, b):
    return sum(x * b.get(w, 0.0) for w, x in a.items())


def chunk_text(text, size=600):
    chunks, cur = [], ""
    for para in re.split(r"\n\s*\n|(?<=\.)\s+(?=[A-Z])", text):
        if len(cur) + len(para) > size and cur:
            chunks.append(cur.strip()); cur = ""
        cur += para + " "
    if cur.strip():
        chunks.append(cur.strip())
    return chunks


class KnowledgeBase:
    def __init__(self):
        self.docs, self.chunks, self.index = [], [], None

    def rebuild(self, conn):
        self.docs = [dict(r) for r in conn.execute("SELECT id,category,title,content FROM kb_documents")]
        for j in conn.execute("SELECT j.id,j.title,j.company,j.description FROM jobs j"):
            skills = ", ".join(r[0] for r in conn.execute(
                "SELECT s.name FROM job_skills js JOIN skills s ON s.id=js.skill_id WHERE js.job_id=?", (j["id"],)))
            self.docs.append({"id": f"job-{j['id']}", "category": "job_description",
                              "title": f"{j['title']} at {j['company']}",
                              "content": f"{j['description']} Required skills: {skills}."})
        self.chunks = [{"category": d["category"], "title": d["title"], "text": c}
                       for d in self.docs for c in chunk_text(d["content"])]
        self.index = Tfidf([f"{c['title']} {c['text']}" for c in self.chunks]) if self.chunks else None

    def search(self, query, k=4, categories=None, min_score=0.05):
        if not self.index:
            return []
        q = self.index.vec(query)
        scored = sorted(((cosine(q, v), c) for v, c in zip(self.index.vecs, self.chunks)
                         if not categories or c["category"] in categories), key=lambda x: -x[0])
        return [{**c, "score": round(s, 3)} for s, c in scored[:k] if s >= min_score]

    def get_skill_doc(self, skill):
        for d in self.docs:
            if d["category"] == "skill" and d["title"].lower() == skill.lower():
                return d
        return None


kb = KnowledgeBase()
