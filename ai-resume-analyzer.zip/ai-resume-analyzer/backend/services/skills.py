"""Skill dictionaries (canonical name -> aliases) and extraction."""
import re

TECH = {
    "python": ["python"], "javascript": ["javascript", "ecmascript"], "typescript": ["typescript"],
    "java": ["java"], "c++": ["c++"], "c#": ["c#"], "go": ["golang"], "sql": ["sql", "mysql", "sqlite"],
    "postgresql": ["postgresql", "postgres"], "mongodb": ["mongodb"], "fastapi": ["fastapi"],
    "django": ["django"], "flask": ["flask"], "spring boot": ["spring boot", "springboot"],
    "node.js": ["node.js", "nodejs"], "react": ["react", "react.js", "reactjs"], "html": ["html", "html5"],
    "css": ["css", "css3"], "rest api": ["rest api", "restful", "rest apis", "rest"], "git": ["git", "github", "gitlab"],
    "docker": ["docker"], "kubernetes": ["kubernetes", "k8s"], "aws": ["aws", "amazon web services"],
    "azure": ["azure"], "linux": ["linux", "ubuntu", "bash"], "ci/cd": ["ci/cd", "jenkins", "github actions"],
    "terraform": ["terraform"], "machine learning": ["machine learning", "ml"], "deep learning": ["deep learning"],
    "nlp": ["nlp", "natural language processing"], "pandas": ["pandas"], "numpy": ["numpy"],
    "scikit-learn": ["scikit-learn", "sklearn"], "tensorflow": ["tensorflow"], "pytorch": ["pytorch"],
    "data analysis": ["data analysis", "data analytics"], "statistics": ["statistics", "statistical"],
    "power bi": ["power bi", "powerbi"], "tableau": ["tableau"], "excel": ["excel"],
    "figma": ["figma"], "agile": ["agile", "scrum"], "testing": ["unit testing", "pytest", "junit", "test automation"],
    # office / HR / administration / teaching skills
    "powerpoint": ["powerpoint", "power point"], "presentation design": ["presentation design", "visual storytelling"],
    "scratch": ["scratch"], "notion": ["notion"], "trello": ["trello"], "microsoft planner": ["microsoft planner"],
    "visual studio": ["visual studio", "vs code"], "overleaf": ["overleaf"],
    "hr": ["hr", "human resources"], "recruitment": ["recruitment", "recruiting"],
    "administrative": ["administrative", "administration"], "reporting": ["reporting", "reports"],
    "teaching": ["teaching", "instructor", "trainer", "training sessions"], "programming": ["programming"],
    "front-end": ["front-end", "frontend", "front end"],
}
SOFT = {
    "communication": ["communication", "communicated", "presentation skills"], "leadership": ["leadership", "led a team", "team lead", "led"],
    "teamwork": ["teamwork", "team player", "collaborated", "collaboration"], "problem solving": ["problem solving", "problem-solving", "troubleshooting"],
    "time management": ["time management", "prioritization"], "adaptability": ["adaptability", "adaptable", "fast learner"],
    "critical thinking": ["critical thinking", "analytical"], "mentoring": ["mentoring", "mentored", "coaching"],
    "creativity": ["creativity", "creative"], "project management": ["project management", "managed projects"],
}


def _pattern(alias):
    return re.compile(r"(?<![A-Za-z0-9+#])" + re.escape(alias) + r"(?![A-Za-z0-9+#])", re.I)


_TECH_RE = {k: [_pattern(a) for a in v] for k, v in TECH.items()}
_SOFT_RE = {k: [_pattern(a) for a in v] for k, v in SOFT.items()}


def _scan(text, table):
    return sorted(k for k, pats in table.items() if any(p.search(text) for p in pats))


def extract_skills(text: str) -> dict:
    return {"technical": _scan(text, _TECH_RE), "soft": _scan(text, _SOFT_RE)}


def extract_technical(text: str) -> list:
    return _scan(text, _TECH_RE)
