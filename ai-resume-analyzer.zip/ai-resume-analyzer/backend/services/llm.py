"""Optional Anthropic API client. Every caller must handle a None result (offline fallback)."""
import os
import httpx


def available() -> bool:
    return bool(os.getenv("ANTHROPIC_API_KEY"))


def complete(system: str, prompt: str, max_tokens: int = 700):
    if not available():
        return None
    try:
        r = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            json={"model": os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5"), "max_tokens": max_tokens,
                  "system": system, "messages": [{"role": "user", "content": prompt}]},
            timeout=40)
        r.raise_for_status()
        return "".join(b.get("text", "") for b in r.json()["content"]).strip() or None
    except Exception:
        return None
