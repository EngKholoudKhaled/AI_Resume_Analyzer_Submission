"""PDF / DOCX text extraction with validation."""
import io, os

MAX_BYTES = 5 * 1024 * 1024
ALLOWED = {".pdf", ".docx"}


class ParseError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def extract_text(filename: str, data: bytes) -> str:
    ext = os.path.splitext(filename or "")[1].lower()
    if ext not in ALLOWED:
        raise ParseError("Unsupported file type. Please upload a PDF or DOCX resume.", 415)
    if not data:
        raise ParseError("The uploaded file is empty.")
    if len(data) > MAX_BYTES:
        raise ParseError("File is too large (max 5 MB).", 413)
    try:
        text = _pdf(data) if ext == ".pdf" else _docx(data)
    except ParseError:
        raise
    except Exception:
        raise ParseError("The file could not be read. It may be corrupted or password-protected.", 422)
    text = "\n".join(line.rstrip() for line in text.splitlines()).strip()
    if len(text) < 50:
        raise ParseError("No readable text found. Scanned/image-only resumes are not supported.", 422)
    return text


def _pdf(data):
    import pdfplumber
    with pdfplumber.open(io.BytesIO(data)) as pdf:
        return "\n".join((p.extract_text() or "") for p in pdf.pages)


def _docx(data):
    import docx
    d = docx.Document(io.BytesIO(data))
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            parts.append(" | ".join(c.text for c in row.cells))
    return "\n".join(parts)
