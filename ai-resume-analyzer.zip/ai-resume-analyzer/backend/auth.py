"""Password hashing and DB-backed bearer-token sessions."""
import hashlib, hmac, os, secrets, time
from fastapi import Depends, Header, HTTPException
from .database import get_db

SESSION_TTL = 60 * 60 * 24  # 24h


def hash_password(pw: str) -> str:
    salt = os.urandom(16)
    return salt.hex() + ":" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 150_000).hex()


def verify_password(pw: str, stored: str) -> bool:
    salt, digest = stored.split(":")
    calc = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 150_000).hex()
    return hmac.compare_digest(calc, digest)


def create_session(conn, user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    conn.execute("INSERT INTO sessions VALUES(?,?,?)", (token, user_id, time.time()))
    conn.commit()
    return token


def bearer(authorization: str = Header(default=None)) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Authentication required. Please log in.")
    return authorization[7:].strip()


def current_user(token: str = Depends(bearer), conn=Depends(get_db)):
    row = conn.execute("SELECT u.id,u.email,s.created FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?",
                       (token,)).fetchone()
    if not row or time.time() - row["created"] > SESSION_TTL:
        raise HTTPException(401, "Session expired or invalid. Please log in again.")
    return {"id": row["id"], "email": row["email"]}
