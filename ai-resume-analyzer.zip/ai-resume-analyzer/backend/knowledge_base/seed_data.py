"""Seed knowledge base (skills, roadmaps, guidelines) and sample jobs."""

# skill: (description, certifications, learning resources)
SKILLS = {
    "python": ("General-purpose language used for backend, automation, data science and AI.", "PCEP / PCAP (Python Institute); Google IT Automation with Python", "Official Python Tutorial; Automate the Boring Stuff with Python; Real Python"),
    "javascript": ("Language of the web for interactive front ends and Node.js back ends.", "Meta Front-End Developer Certificate; freeCodeCamp JavaScript Algorithms", "MDN JavaScript Guide; javascript.info; Eloquent JavaScript"),
    "typescript": ("Typed superset of JavaScript that improves maintainability of large codebases.", "Microsoft/Udemy TypeScript courses (course completion)", "TypeScript Handbook; Total TypeScript tutorials"),
    "java": ("Statically typed language widely used in enterprise back-end systems.", "Oracle Certified Professional: Java SE", "Oracle Java Tutorials; Effective Java (book); Baeldung"),
    "sql": ("Language for querying relational databases; essential for backend and data roles.", "Oracle Database SQL Certified Associate; Microsoft DP-300", "SQLBolt; Mode SQL Tutorial; PostgreSQL Tutorial"),
    "postgresql": ("Advanced open-source relational database.", "EDB PostgreSQL Associate Certification", "PostgreSQL official docs; PostgreSQL Tutorial"),
    "mongodb": ("Document-oriented NoSQL database.", "MongoDB Associate Developer", "MongoDB University free courses"),
    "fastapi": ("Modern Python web framework for building typed, high-performance REST APIs.", "No official certification; build a portfolio API", "FastAPI official tutorial; TestDriven.io FastAPI guides"),
    "django": ("Batteries-included Python web framework.", "No official certification; portfolio project", "Django official tutorial; Django for Beginners (book)"),
    "flask": ("Lightweight Python microframework.", "No official certification; portfolio project", "Flask Mega-Tutorial by Miguel Grinberg"),
    "react": ("Component-based JavaScript UI library.", "Meta Front-End Developer Certificate", "react.dev Learn; Scrimba React course"),
    "node.js": ("JavaScript runtime for server-side applications.", "OpenJS Node.js Application Developer (JSNAD)", "Node.js official docs; The Odin Project Node path"),
    "html": ("Markup language that structures web pages.", "freeCodeCamp Responsive Web Design", "MDN HTML Guide; web.dev Learn HTML"),
    "css": ("Styling language for the web including layout with Flexbox and Grid.", "freeCodeCamp Responsive Web Design", "MDN CSS Guide; web.dev Learn CSS; CSS-Tricks"),
    "rest api": ("Architectural style for designing web services (resources, verbs, status codes).", "No formal certification; document an API with OpenAPI", "RESTfulAPI.net; Microsoft REST API guidelines"),
    "git": ("Distributed version control used by virtually every engineering team.", "GitHub Foundations Certification", "Pro Git (free book); GitHub Skills"),
    "docker": ("Container platform for packaging and running applications consistently.", "Docker Certified Associate", "Docker Get Started guide; Play with Docker"),
    "kubernetes": ("Container orchestration platform.", "CKA / CKAD (CNCF)", "Kubernetes official tutorials; Kubernetes the Hard Way"),
    "aws": ("Leading cloud platform for compute, storage, networking and managed services.", "AWS Certified Cloud Practitioner; AWS Solutions Architect Associate", "AWS Skill Builder; freeCodeCamp AWS course"),
    "linux": ("Operating system knowledge and shell skills for servers and DevOps.", "LPIC-1; CompTIA Linux+", "Linux Journey; The Linux Command Line (book)"),
    "ci/cd": ("Automated build, test and deployment pipelines.", "GitHub Actions Certification", "GitHub Actions docs; Jenkins handbook"),
    "terraform": ("Infrastructure-as-code tool.", "HashiCorp Certified: Terraform Associate", "HashiCorp Learn tutorials"),
    "machine learning": ("Building models that learn patterns from data.", "TensorFlow Developer Certificate; Google Professional ML Engineer", "Andrew Ng Machine Learning Specialization; scikit-learn user guide; Kaggle Learn"),
    "deep learning": ("Neural network techniques for vision, language and speech.", "DeepLearning.AI Deep Learning Specialization", "fast.ai Practical Deep Learning; PyTorch tutorials"),
    "nlp": ("Natural language processing: text classification, embeddings and LLM applications.", "DeepLearning.AI NLP Specialization", "Hugging Face NLP Course; Stanford CS224n"),
    "pandas": ("Python library for tabular data manipulation.", "Kaggle Pandas micro-course certificate", "pandas User Guide; Kaggle Learn Pandas"),
    "numpy": ("Numerical computing library for Python.", "Kaggle/Coursera data-science certificates", "NumPy quickstart; Python Data Science Handbook"),
    "scikit-learn": ("Classic machine-learning library for Python.", "IBM Machine Learning Professional Certificate", "scikit-learn tutorials; Hands-On Machine Learning (book)"),
    "tensorflow": ("Deep-learning framework by Google.", "TensorFlow Developer Certificate", "TensorFlow tutorials; DeepLearning.AI TF specialization"),
    "pytorch": ("Deep-learning framework popular in research and production.", "PyTorch course certificates (Udacity/Coursera)", "Official PyTorch tutorials; fast.ai"),
    "data analysis": ("Cleaning, exploring and communicating insights from data.", "Google Data Analytics Professional Certificate", "Kaggle Learn; Storytelling with Data (book)"),
    "statistics": ("Probability and inference foundations for data work.", "Khan Academy / Coursera statistics certificates", "Khan Academy Statistics; StatQuest on YouTube"),
    "power bi": ("Microsoft business-intelligence and dashboard tool.", "Microsoft PL-300 Power BI Data Analyst", "Microsoft Learn Power BI path"),
    "tableau": ("Data-visualisation tool for dashboards.", "Tableau Desktop Specialist", "Tableau free training videos"),
    "excel": ("Spreadsheet analysis with formulas, pivots and charts.", "Microsoft Office Specialist: Excel", "Microsoft Excel support training; ExcelIsFun"),
    "agile": ("Iterative delivery practices such as Scrum and Kanban.", "Professional Scrum Master I; PMI-ACP", "Scrum Guide (free); Atlassian Agile Coach"),
    "testing": ("Automated unit and integration testing to keep software reliable.", "ISTQB Foundation Level", "pytest docs; Test Automation University"),
    "azure": ("Microsoft cloud platform.", "AZ-900 Azure Fundamentals; AZ-204", "Microsoft Learn Azure paths"),
    "figma": ("Collaborative interface design tool.", "Google UX Design Certificate", "Figma Learn; Refactoring UI (book)"),
    "communication": ("Clear written and verbal communication with technical and non-technical people.", "Toastmasters (practice programme)", "Crucial Conversations (book); Google Tech Writing course"),
    "leadership": ("Guiding people and projects; showing ownership.", "PMP / CSM (for project-focused paths)", "The Manager's Path (book); LinkedIn Learning leadership courses"),
    "teamwork": ("Working effectively with peers across roles.", "None required; show examples in your resume", "Team Topologies (book); Google re:Work guides"),
    "problem solving": ("Structured approach to breaking down and solving problems.", "None required; competitive coding practice helps", "LeetCode; Cracking the Coding Interview (book)"),
    "hr": ("Human resources: recruitment, onboarding, employee relations and internal communication.", "SHRM-CP; CIPD Foundation; Google/Alison HR courses", "Coursera HR Management; LinkedIn Learning HR Foundations"),
    "recruitment": ("Sourcing, screening and hiring candidates.", "AIRS Certified Recruiter; LinkedIn Recruiter certification", "LinkedIn Learning: Recruiting Foundations"),
    "administrative": ("Office coordination, scheduling, correspondence and reporting.", "IAAP Certified Administrative Professional; Microsoft Office Specialist", "Coursera Administrative Assistant courses"),
    "powerpoint": ("Presentation software for slides and visual storytelling.", "Microsoft Office Specialist: PowerPoint", "Microsoft PowerPoint training; Presentation Zen (book)"),
    "presentation design": ("Turning information into clear, persuasive slides.", "Microsoft Office Specialist: PowerPoint", "Coursera: Presentation design; Storytelling with Data (book)"),
    "teaching": ("Planning lessons and explaining concepts clearly to learners.", "TEFL; Google Certified Educator", "Coursera: Learning to Teach Online; Teach Like a Champion (book)"),
    "scratch": ("Visual block-based language that introduces children to programming.", "None official; build and share Scratch projects", "scratch.mit.edu tutorials; Scratch Educator guides"),
    "programming": ("Core programming fundamentals: variables, loops, functions, problem solving.", "PCEP (Python Institute); freeCodeCamp certifications", "CS50 (Harvard, free); freeCodeCamp"),
    "notion": ("Workspace for notes, tasks and databases.", "None official", "Notion Academy guides"),
    "trello": ("Kanban-style task management boards.", "None official", "Trello Guide; Atlassian Agile Coach"),
    "project management": ("Planning, tracking and delivering work on time and on budget.", "PMI CAPM; Google Project Management Certificate", "Coursera Google Project Management; PMI Fundamentals"),
    "reporting": ("Preparing clear, data-based reports for decision makers.", "Google Data Analytics Professional Certificate", "Storytelling with Data (book); Kaggle Learn"),
    "front-end": ("Building the user-facing part of web applications.", "Meta Front-End Developer Certificate; freeCodeCamp Responsive Web Design", "MDN Learn Web Development; The Odin Project"),
}

ROADMAPS = {
    "HR Coordinator": "Learn HR fundamentals and labour-law basics, practise recruitment and onboarding processes, master Excel and PowerPoint for reporting, learn project management, then earn SHRM-CP or CIPD.",
    "Programming Instructor": "Master programming fundamentals, learn Scratch and one text language such as Python, practise lesson planning and presentation design, build small student projects, and earn a teaching certificate.",
    "Backend Developer": "Learn a language (Python, Java or Node.js), then HTTP and REST API design, then SQL and one NoSQL database, authentication and security basics, testing, Git, Docker, and finally cloud deployment with CI/CD. Build 2-3 portfolio APIs with documentation. Junior to mid: focus on clean code and databases. Senior: system design, scalability and mentoring.",
    "Frontend Developer": "Start with HTML, CSS and accessibility, then JavaScript fundamentals, Git, responsive design, a framework such as React, TypeScript, testing and performance optimisation. Build a portfolio of 3 responsive projects with real API data.",
    "Data Scientist": "Build a foundation in Python, statistics and SQL, then pandas and numpy, data visualisation, machine learning with scikit-learn, and deep learning. Practise on Kaggle, learn model deployment, and publish notebooks with clear storytelling.",
    "DevOps Engineer": "Learn Linux and shell scripting, Git, networking basics, Docker, CI/CD pipelines, a cloud provider such as AWS, Kubernetes, infrastructure as code with Terraform, and monitoring. Earn AWS and CKA certifications.",
    "AI / ML Engineer": "Master Python, mathematics for ML, machine learning, deep learning with PyTorch or TensorFlow, NLP and LLM application development including retrieval-augmented generation, then MLOps: Docker, model serving and monitoring.",
}

GUIDELINES = {
    "Quantify achievements": "Use numbers to show impact, for example 'reduced API latency by 35%' or 'served 10,000 monthly users'. Start bullets with strong action verbs such as built, led, optimised, automated.",
    "Structure and length": "Use clear sections: Contact, Summary, Skills, Experience, Education, Projects, Certifications. Keep to one page for under 5 years of experience and two pages otherwise. Use a simple single-column layout so applicant tracking systems can parse it.",
    "Tailor to the job": "Mirror keywords from the job description in your skills and experience sections. Reorder bullets so the most relevant achievements come first. Never list skills you cannot discuss in an interview.",
    "Professional summary": "Write a 2-3 sentence summary at the top stating your role, years of experience, key technologies and one headline achievement.",
    "Projects and links": "Include links to GitHub, a portfolio and LinkedIn. Describe each project with the problem, the technologies used and the measurable outcome. Add certifications with issue dates.",
}

JOBS = [
    {"title": "Backend Python Developer", "company": "Nile Tech", "location": "Cairo, Egypt", "type": "Full-time",
     "description": "Design and build REST APIs with FastAPI and PostgreSQL. Write tests, containerise services with Docker, and collaborate with frontend engineers in an agile team.",
     "skills": ["python", "fastapi", "postgresql", "docker", "rest api", "git", "testing", "teamwork"]},
    {"title": "Full-Stack Web Developer", "company": "PixelWorks", "location": "Remote", "type": "Full-time",
     "description": "Build responsive web applications using React, Node.js and MongoDB. Own features from design to deployment and communicate progress clearly.",
     "skills": ["javascript", "react", "node.js", "mongodb", "html", "css", "git", "communication"]},
    {"title": "Data Analyst", "company": "InsightCo", "location": "Alexandria, Egypt", "type": "Full-time",
     "description": "Analyse business data using SQL, Excel and Power BI. Build dashboards, present insights to stakeholders and support data-driven decisions with statistics.",
     "skills": ["sql", "excel", "power bi", "data analysis", "statistics", "communication", "critical thinking"]},
    {"title": "Machine Learning Engineer", "company": "DeepNile AI", "location": "Remote", "type": "Full-time",
     "description": "Train and deploy machine learning and NLP models using Python, PyTorch and scikit-learn. Build data pipelines with pandas and serve models through APIs.",
     "skills": ["python", "machine learning", "pytorch", "scikit-learn", "pandas", "nlp", "docker", "problem solving"]},
    {"title": "DevOps Engineer", "company": "CloudBridge", "location": "Dubai, UAE", "type": "Full-time",
     "description": "Automate infrastructure on AWS with Terraform, maintain Kubernetes clusters and CI/CD pipelines, and monitor production systems on Linux.",
     "skills": ["aws", "kubernetes", "docker", "terraform", "ci/cd", "linux", "git", "problem solving"]},
    {"title": "Frontend Developer Intern", "company": "PixelWorks", "location": "Cairo, Egypt", "type": "Internship",
     "description": "Assist in building user interfaces with HTML, CSS and JavaScript. Learn Git workflows and work with designers in Figma.",
     "skills": ["html", "css", "javascript", "git", "figma", "teamwork", "adaptability"]},
    {"title": "HR Coordinator", "company": "PeopleFirst", "location": "Cairo, Egypt", "type": "Full-time",
     "description": "Support recruitment, onboarding and internal communication. Prepare HR reports in Excel, create presentations and coordinate projects with managers.",
     "skills": ["hr", "recruitment", "excel", "powerpoint", "project management", "communication"]},
    {"title": "Administrative Assistant", "company": "OfficePro", "location": "Remote", "type": "Full-time",
     "description": "Coordinate schedules and meetings, prepare weekly reports and presentations, and organise team tasks with digital tools such as Notion and Trello.",
     "skills": ["administrative", "excel", "powerpoint", "notion", "trello", "reporting", "time management"]},
    {"title": "Programming Instructor", "company": "Coding Kids Academy", "location": "Cairo, Egypt", "type": "Part-time",
     "description": "Teach programming to school students using Scratch and introductory text languages. Design engaging lessons and present concepts clearly.",
     "skills": ["programming", "teaching", "scratch", "presentation design", "communication"]},
    {"title": "Java Software Engineer", "company": "BankOne", "location": "Riyadh, Saudi Arabia", "type": "Full-time",
     "description": "Develop secure enterprise services with Java and Spring Boot, work with SQL databases, write unit tests and follow agile practices.",
     "skills": ["java", "spring boot", "sql", "rest api", "testing", "agile", "git"]},
    {"title": "Freelance Technical Writer & Developer Advocate", "company": "DevDocs", "location": "Remote", "type": "Contract",
     "description": "Write tutorials and documentation for developer tools, create sample projects in Python and JavaScript, and present at community events.",
     "skills": ["python", "javascript", "communication", "git", "creativity", "rest api"]},
]


def build_kb_documents():
    docs = []
    for name, (desc, certs, res) in SKILLS.items():
        docs.append(("skill", name, f"{name}: {desc} Certifications: {certs}. Resources: {res}."))
    for name, text in ROADMAPS.items():
        docs.append(("roadmap", name, f"Career roadmap for {name}. {text}"))
    for name, text in GUIDELINES.items():
        docs.append(("guideline", name, f"Resume writing guideline: {name}. {text}"))
    for name, (_, _, res) in SKILLS.items():
        docs.append(("resource", f"Learn {name}", f"Learning resources for {name}: {res}."))
    return docs
