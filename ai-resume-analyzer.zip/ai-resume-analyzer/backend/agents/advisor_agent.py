"""Career Advisor Agent: RAG-grounded answers, skill-gap improvement plans."""
import re
from ..services import llm
from ..services.rag import kb

SYSTEM = ("You are a career advisor for job seekers. Answer ONLY using the provided knowledge-base context and candidate profile. "
          "If the context is insufficient, say so and give general, cautious guidance. Be concise, practical and use short bullet points.")


def _parse_skill_doc(doc):
    if not doc:
        return [], []
    c = re.search(r"Certifications:\s*(.*?)\.\s*Resources:", doc["content"])
    r = re.search(r"Resources:\s*(.*)\.?$", doc["content"])
    split = lambda s: [x.strip().rstrip(".") for x in s.split(";") if x.strip()] if s else []
    return split(c.group(1) if c else ""), split(r.group(1) if r else "")


def improvement_plan(analysis: dict, target: dict | None):
    """FR-5: missing skills, weaknesses, improvements, certifications, learning resources."""
    missing = target["missing_skills"] if target else []
    certs, resources = [], []
    for s in missing:
        c, r = _parse_skill_doc(kb.get_skill_doc(s))
        certs += [{"skill": s, "certification": x} for x in c]
        resources += [{"skill": s, "resource": x} for x in r]
    guidelines = [{"title": h["title"], "text": h["text"]} for h in kb.search(" ".join(analysis["weaknesses"]) or "resume", 3, ["guideline"], 0.0)]
    return {"target_job": target["job"] if target else None, "missing_skills": missing,
            "weaknesses": analysis["weaknesses"], "improvements": analysis["improvements"],
            "certifications": certs, "learning_resources": resources, "writing_guidelines": guidelines}


def answer(question: str, analysis: dict | None, history: list):
    hits = kb.search(question, 5, min_score=0.04)
    context = "\n".join(f"[{h['category']}] {h['title']}: {h['text']}" for h in hits)
    profile = ""
    if analysis:
        s = analysis["skills"]
        profile = (f"Candidate skills: {', '.join(s['technical'] + s['soft']) or 'unknown'}. "
                   f"Experience: {analysis['experience']['years']} years ({analysis['experience']['level']}). "
                   f"Weaknesses: {'; '.join(analysis['weaknesses']) or 'none'}.")
    sources = [{"title": h["title"], "category": h["category"]} for h in hits]
    convo = "\n".join(f"{m['role']}: {m['content']}" for m in history[-6:])
    ai = llm.complete(SYSTEM, f"Knowledge-base context:\n{context or '(none found)'}\n\nCandidate profile: {profile or 'not provided'}\n\n"
                              f"Recent conversation:\n{convo}\n\nQuestion: {question}", 600)
    if ai:
        return {"answer": ai, "sources": sources, "mode": "llm+rag"}
    if not hits:
        return {"answer": "I could not find relevant guidance in the knowledge base for that. Try asking about a skill, a career roadmap (backend, frontend, data science, DevOps, AI/ML), certifications, or resume writing.",
                "sources": [], "mode": "offline"}
    lines = [f"Here is what the knowledge base says that is relevant to your question:"]
    for h in hits[:3]:
        lines.append(f"- {h['title']} ({h['category']}): {h['text']}")
    if profile:
        lines.append(f"\nYour profile: {profile}")
    return {"answer": "\n".join(lines), "sources": sources, "mode": "offline"}
