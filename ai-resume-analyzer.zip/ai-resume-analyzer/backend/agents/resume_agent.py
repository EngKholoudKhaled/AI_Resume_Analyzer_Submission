"""Resume Analyzer Agent: extract structured info, weaknesses and a summary."""
import re
from datetime import date
from ..services import llm
from ..services.skills import extract_skills

DEGREE = re.compile(r"\b(bachelor|b\.?sc|b\.?eng|b\.?a\b|master|m\.?sc|m\.?eng|ph\.?d|diploma|mba|associate degree|university|college|institute|faculty)\b", re.I)
RANGE = re.compile(r"(?:([A-Za-z]{3})[a-z]*\.?\s+)?((?:19|20)\d{2})\s*(?:-|–|—|to)\s*(?:([A-Za-z]{3})[a-z]*\.?\s+)?((?:19|20)\d{2}|present|current|now)", re.I)
MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}
WORDNUM = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
EXPL = re.compile(r"(\d{1,2}|" + "|".join(WORDNUM) + r")\+?\s*(?:years|yrs)", re.I)
EDU_LINE = re.compile(r"\b(bachelor|b\.?sc|b\.?eng|master|m\.?sc|m\.?eng|ph\.?d|diploma|mba)\b", re.I)  # study periods are not work experience
EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
PHONE = re.compile(r"(?:\+?\d[\d\s().-]{8,}\d)")
NUMBER_IMPACT = re.compile(r"\d+\s*%|\$\s*\d|\b\d{2,}[,\d]*\s*(users|customers|requests|clients|projects)\b|\b(increased|reduced|improved|decreased)\b.*\d", re.I)


def _name(lines):
    for l in lines[:5]:
        if "@" in l or re.search(r"\d", l):
            continue
        words = l.split()
        if 2 <= len(words) <= 4 and all(re.fullmatch(r"[A-Za-z.'-]+", w) for w in words):
            return l.strip()
    return None


def analyze(text: str) -> dict:
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    skills = extract_skills(text)
    email, phone = EMAIL.search(text), PHONE.search(text)
    contact = {"name": _name(lines), "email": email.group(0) if email else None,
               "phone": phone.group(0).strip() if phone else None,
               "linkedin": bool(re.search(r"linkedin\.com", text, re.I)),
               "github": bool(re.search(r"github\.com", text, re.I))}

    education = [l[:160] for l in lines if DEGREE.search(l) and len(l) < 200][:5]
    for i, l in enumerate(lines):  # prefer the real Education section when present
        if re.fullmatch(r"education( (&|and) training)?:?", l, re.I):
            sec = []
            for x in lines[i + 1:i + 4]:
                if (x.isupper() and len(x) < 40) or (len(x) < 25 and not re.search(r"[\d,|]", x)):
                    break
                sec.append(x[:160])
            if sec:
                education = sec
            break

    now = date.today().year + date.today().month / 12
    spans, entries = [], []
    for l in lines:
        if EDU_LINE.search(l):
            continue
        for m1, y1, m2, y2 in RANGE.findall(l):
            a = int(y1) + MONTHS.get(m1.lower(), 0) / 12
            b = now if y2.lower() in ("present", "current", "now") else int(y2) + ((MONTHS[m2.lower()] + 1) / 12 if m2.lower() in MONTHS else 0)
            if b > a:
                spans.append((a, b)); entries.append(l[:160])
    total, cur_end = 0.0, None
    for a, b in sorted(spans):  # union of periods: overlapping jobs are not double counted
        if cur_end is None or a > cur_end:
            total += b - a; cur_end = b
        elif b > cur_end:
            total += b - cur_end; cur_end = b
    explicit = max([int(WORDNUM.get(x.lower(), x)) for x in EXPL.findall(text)] or [0])
    years = round(min(40, max(total, explicit)), 1)
    level = "junior" if years < 2 else "mid-level" if years < 5 else "senior"
    experience = {"years": years, "level": level, "entries": list(dict.fromkeys(entries))[:8]}

    weaknesses, improvements = [], []
    words = len(text.split())
    if not contact["email"] or not contact["phone"]:
        weaknesses.append("Contact details are incomplete."); improvements.append("Add a professional email and phone number at the top.")
    if not (contact["linkedin"] or contact["github"]):
        weaknesses.append("No LinkedIn or GitHub links."); improvements.append("Add links to your LinkedIn profile and GitHub/portfolio.")
    if len(skills["technical"]) < 5:
        weaknesses.append("Few technical skills detected."); improvements.append("Add a dedicated Skills section listing tools and technologies you have used.")
    if len(skills["soft"]) < 2:
        weaknesses.append("Soft skills are hardly demonstrated."); improvements.append("Show teamwork, communication or leadership through concrete examples.")
    if not NUMBER_IMPACT.search(text):
        weaknesses.append("Achievements are not quantified."); improvements.append("Add measurable results such as '% improvement', users served, or time saved.")
    if not re.search(r"\b(summary|profile|objective|about)\b", text, re.I):
        weaknesses.append("No professional summary section."); improvements.append("Open with a 2-3 sentence professional summary.")
    if not entries and not re.search(r"\bproject", text, re.I):
        weaknesses.append("No clear experience timeline or projects."); improvements.append("List roles with dates (e.g. 2022 - 2024) or add a Projects section.")
    if not education:
        weaknesses.append("Education details not found."); improvements.append("Add a clear Education section with degree, institution and year.")
    if words < 150:
        weaknesses.append("Resume is very short."); improvements.append("Expand with more detail on responsibilities and results.")
    elif words > 1100:
        weaknesses.append("Resume is very long."); improvements.append("Trim to the most relevant 1-2 pages.")

    top = ", ".join(skills["technical"][:6]) or "no clearly listed technologies"
    summary = (f"{contact['name'] or 'The candidate'} appears to be a {level} professional with about {years} year(s) of experience. "
               f"Key technical skills: {top}. " + (f"Education: {education[0]}." if education else "Education details were not detected."))
    ai = llm.complete(
        "You are a resume analyst. Write a factual 3-4 sentence professional summary of the candidate. No invented facts.",
        f"Resume text:\n{text[:6000]}\n\nDetected skills: {skills}")
    if ai:
        summary = ai
    return {"contact": contact, "skills": skills, "education": education, "experience": experience,
            "summary": summary, "weaknesses": weaknesses, "improvements": improvements}
