"""Job Matching Agent: score = 0.6 * skill overlap + 0.4 * semantic (TF-IDF cosine) similarity."""
from ..database import job_dict
from ..services import llm
from ..services.rag import Tfidf, cosine
from ..services.skills import extract_technical

W_SKILL, W_SEM = 0.6, 0.4


def match(conn, resume_text: str, resume_skills: list, job_ids=None) -> list:
    rows = conn.execute("SELECT * FROM jobs").fetchall()
    jobs = [job_dict(conn, r) for r in rows if not job_ids or r["id"] in job_ids]
    if not jobs:
        return []
    tf = Tfidf([resume_text] + [f"{j['title']} {j['description']} {' '.join(j['skills'])}" for j in jobs])
    rv, have = tf.vecs[0], set(resume_skills)
    results = []
    for j, jv in zip(jobs, tf.vecs[1:]):
        required = set(j["skills"]) or set(extract_technical(j["description"]))
        matched, missing = sorted(required & have), sorted(required - have)
        overlap = len(matched) / len(required) if required else 0.0
        semantic = min(1.0, cosine(rv, jv) * 2.0)  # raw cosine is small for long docs; rescale
        score = round(100 * (W_SKILL * overlap + W_SEM * semantic), 1)
        results.append({"job": j, "score": score, "skill_overlap": round(overlap * 100, 1),
                        "semantic_similarity": round(semantic * 100, 1), "matched_skills": matched, "missing_skills": missing})
    results.sort(key=lambda r: -r["score"])
    for i, r in enumerate(results):
        r["explanation"] = _explain(r, resume_text) if i < 3 else _template(r)
    return results


def _template(r):
    j = r["job"]
    m = ", ".join(r["matched_skills"]) or "none of the listed skills"
    txt = (f"You match {len(r['matched_skills'])} of {len(r['matched_skills']) + len(r['missing_skills'])} required skills for "
           f"{j['title']} at {j['company']} (matched: {m}). Overall content similarity to the job description is {r['semantic_similarity']}%.")
    if r["missing_skills"]:
        txt += " To strengthen this match, learn: " + ", ".join(r["missing_skills"][:5]) + "."
    return txt


def _explain(r, resume_text):
    j = r["job"]
    ai = llm.complete(
        "You are a job-matching agent. In 2-3 sentences explain why this job does or does not fit the candidate. Use only the facts given.",
        f"Job: {j['title']} at {j['company']}\nDescription: {j['description']}\nMatched skills: {r['matched_skills']}\n"
        f"Missing skills: {r['missing_skills']}\nScore: {r['score']}/100\nResume excerpt: {resume_text[:1500]}", 250)
    return ai or _template(r)
