"""AI Resume Analyzer - FastAPI entry point.  Run:  uvicorn backend.main:app --reload"""
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from .database import connect, init_db
from .routers import advisor, auth, jobs, resumes
from .services import llm
from .services.rag import kb


@asynccontextmanager
async def lifespan(app):
    init_db()
    conn = connect(); kb.rebuild(conn); conn.close()
    yield


app = FastAPI(title="AI Resume Analyzer", version="1.0.0", lifespan=lifespan,
              description="Resume analysis, job matching and career advice with AI agents + RAG.")


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    msgs = [f"{'.'.join(str(p) for p in e['loc'] if p != 'body')}: {e['msg']}" for e in exc.errors()]
    return JSONResponse(status_code=422, content={"detail": "Invalid input - " + "; ".join(msgs)})


@app.get("/api/health", tags=["System"])
def health():
    return {"status": "ok", "ai_mode": "llm+rag" if llm.available() else "offline (TF-IDF RAG)"}


for r in (auth.router, resumes.router, jobs.router, advisor.router):
    app.include_router(r)

FRONTEND = os.path.join(os.path.dirname(__file__), "..", "frontend")
app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
