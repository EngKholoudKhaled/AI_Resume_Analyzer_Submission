import json
from typing import Optional
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from ..agents import advisor_agent, matching_agent, resume_agent
from ..auth import current_user
from ..database import get_db
from ..services import parser

router = APIRouter(prefix="/api/resumes", tags=["Resumes"])
JSON_COLS = ("contact", "skills", "education", "experience", "weaknesses", "improvements")


def _own_resume(conn, rid, user):
    r = conn.execute("SELECT * FROM resumes WHERE id=? AND user_id=?", (rid, user["id"])).fetchone()
    if not r:
        raise HTTPException(404, "Resume not found.")
    return r


def _analysis(conn, rid):
    a = conn.execute("SELECT * FROM analyses WHERE resume_id=?", (rid,)).fetchone()
    if not a:
        raise HTTPException(404, "No analysis found for this resume.")
    d = dict(a)
    for c in JSON_COLS:
        d[c] = json.loads(d[c])
    return d


@router.post("", status_code=201)
async def upload_resume(file: UploadFile = File(...), user=Depends(current_user), conn=Depends(get_db)):
    data = await file.read()
    try:
        text = parser.extract_text(file.filename, data)
    except parser.ParseError as e:
        raise HTTPException(e.status, str(e))
    a = resume_agent.analyze(text)
    rid = conn.execute("INSERT INTO resumes(user_id,filename,raw_text) VALUES(?,?,?)", (user["id"], file.filename, text)).lastrowid
    conn.execute("INSERT INTO analyses(resume_id,contact,skills,education,experience,summary,weaknesses,improvements) VALUES(?,?,?,?,?,?,?,?)",
                 (rid, *[json.dumps(a[c]) for c in ("contact", "skills", "education", "experience")], a["summary"],
                  json.dumps(a["weaknesses"]), json.dumps(a["improvements"])))
    conn.commit()
    return {"id": rid, "filename": file.filename, "analysis": _analysis(conn, rid)}


@router.get("")
def list_resumes(user=Depends(current_user), conn=Depends(get_db)):
    return [dict(r) for r in conn.execute(
        "SELECT id,filename,uploaded_at FROM resumes WHERE user_id=? ORDER BY id DESC", (user["id"],))]


@router.delete("/{rid}", status_code=204)
def delete_resume(rid: int, user=Depends(current_user), conn=Depends(get_db)):
    _own_resume(conn, rid, user)
    conn.execute("DELETE FROM resumes WHERE id=?", (rid,))
    conn.commit()


@router.get("/{rid}/analysis")
def get_analysis(rid: int, user=Depends(current_user), conn=Depends(get_db)):
    r = _own_resume(conn, rid, user)
    return {"id": rid, "filename": r["filename"], "analysis": _analysis(conn, rid)}


def _recommend(conn, rid, user, limit=None):
    r = _own_resume(conn, rid, user)
    a = _analysis(conn, rid)
    res = matching_agent.match(conn, r["raw_text"], a["skills"]["technical"] + a["skills"]["soft"])
    conn.execute("DELETE FROM recommendations WHERE resume_id=?", (rid,))
    conn.executemany("INSERT INTO recommendations(resume_id,job_id,score,explanation) VALUES(?,?,?,?)",
                     [(rid, x["job"]["id"], x["score"], x["explanation"]) for x in res])
    conn.commit()
    return res[:limit] if limit else res


@router.get("/{rid}/recommendations")
def recommendations(rid: int, limit: int = 10, user=Depends(current_user), conn=Depends(get_db)):
    return _recommend(conn, rid, user, max(1, min(limit, 50)))


@router.get("/{rid}/improvements")
def improvements(rid: int, job_id: Optional[int] = None, user=Depends(current_user), conn=Depends(get_db)):
    a = _analysis(conn, rid)
    recs = _recommend(conn, rid, user)
    target = next((x for x in recs if x["job"]["id"] == job_id), None) if job_id else (recs[0] if recs else None)
    if job_id and not target:
        raise HTTPException(404, "Target job not found.")
    return advisor_agent.improvement_plan(a, target)
