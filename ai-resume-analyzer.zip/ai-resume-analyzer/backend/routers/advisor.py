import json
from typing import Optional
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from ..agents import advisor_agent
from ..auth import current_user
from ..database import get_db

router = APIRouter(prefix="/api/advisor", tags=["Career Advisor"])


class ChatIn(BaseModel):
    message: str = Field(min_length=2, max_length=1000)
    resume_id: Optional[int] = None


@router.post("/chat")
def chat(body: ChatIn, user=Depends(current_user), conn=Depends(get_db)):
    analysis = None
    q = "SELECT a.* FROM analyses a JOIN resumes r ON r.id=a.resume_id WHERE r.user_id=? "
    row = conn.execute(q + ("AND r.id=?" if body.resume_id else "ORDER BY r.id DESC"),
                       (user["id"], body.resume_id) if body.resume_id else (user["id"],)).fetchone()
    if row:
        analysis = {k: json.loads(row[k]) for k in ("skills", "experience", "weaknesses", "improvements")}
    history = [dict(r) for r in conn.execute(
        "SELECT role,content FROM chat_messages WHERE user_id=? ORDER BY id DESC LIMIT 6", (user["id"],))][::-1]
    out = advisor_agent.answer(body.message, analysis, history)
    conn.executemany("INSERT INTO chat_messages(user_id,role,content) VALUES(?,?,?)",
                     [(user["id"], "user", body.message), (user["id"], "assistant", out["answer"])])
    conn.commit()
    return out


@router.get("/history")
def history(limit: int = Query(30, ge=1, le=200), user=Depends(current_user), conn=Depends(get_db)):
    rows = conn.execute("SELECT role,content,created_at FROM chat_messages WHERE user_id=? ORDER BY id DESC LIMIT ?",
                        (user["id"], limit))
    return [dict(r) for r in rows][::-1]
