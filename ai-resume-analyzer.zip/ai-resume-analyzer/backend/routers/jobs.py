from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from ..auth import current_user
from ..database import get_db, job_dict, set_job_skills
from ..services.rag import kb
from ..services.skills import extract_technical

router = APIRouter(prefix="/api/jobs", tags=["Jobs"], dependencies=[Depends(current_user)])


class JobIn(BaseModel):
    title: str = Field(min_length=2, max_length=120)
    company: str = Field(min_length=1, max_length=120)
    location: str = Field(default="", max_length=120)
    job_type: str = Field(default="Full-time", max_length=40)
    description: str = Field(min_length=20, max_length=8000)
    skills: list[str] = Field(default_factory=list, max_length=40)


def _get(conn, job_id):
    row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Job not found.")
    return row


def _save(conn, job_id, j: JobIn):
    set_job_skills(conn, job_id, j.skills or extract_technical(j.description))
    conn.commit()
    kb.rebuild(conn)
    return job_dict(conn, _get(conn, job_id))


@router.get("")
def search_jobs(q: Optional[str] = None, skill: Optional[str] = None, location: Optional[str] = None,
                type: Optional[str] = None, company: Optional[str] = None,
                limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0), conn=Depends(get_db)):
    where, args = [], []
    if q:
        where.append("(j.title LIKE ? OR j.description LIKE ? OR j.company LIKE ?)"); args += [f"%{q}%"] * 3
    if location:
        where.append("j.location LIKE ?"); args.append(f"%{location}%")
    if type:
        where.append("j.job_type LIKE ?"); args.append(type)
    if company:
        where.append("j.company LIKE ?"); args.append(f"%{company}%")
    if skill:
        where.append("EXISTS(SELECT 1 FROM job_skills js JOIN skills s ON s.id=js.skill_id WHERE js.job_id=j.id AND s.name LIKE ?)")
        args.append(skill.lower())
    sql = "SELECT j.* FROM jobs j" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY j.id DESC LIMIT ? OFFSET ?"
    return [job_dict(conn, r) for r in conn.execute(sql, (*args, limit, offset))]


@router.get("/{job_id}")
def get_job(job_id: int, conn=Depends(get_db)):
    return job_dict(conn, _get(conn, job_id))


@router.post("", status_code=201)
def add_job(j: JobIn, conn=Depends(get_db)):
    jid = conn.execute("INSERT INTO jobs(title,company,location,job_type,description) VALUES(?,?,?,?,?)",
                       (j.title, j.company, j.location, j.job_type, j.description)).lastrowid
    return _save(conn, jid, j)


@router.put("/{job_id}")
def edit_job(job_id: int, j: JobIn, conn=Depends(get_db)):
    _get(conn, job_id)
    conn.execute("UPDATE jobs SET title=?,company=?,location=?,job_type=?,description=? WHERE id=?",
                 (j.title, j.company, j.location, j.job_type, j.description, job_id))
    return _save(conn, job_id, j)


@router.delete("/{job_id}", status_code=204)
def delete_job(job_id: int, conn=Depends(get_db)):
    _get(conn, job_id)
    conn.execute("DELETE FROM jobs WHERE id=?", (job_id,))
    conn.commit()
    kb.rebuild(conn)
