import sqlite3
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from ..auth import bearer, create_session, current_user, hash_password, verify_password
from ..database import get_db

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


class Credentials(BaseModel):
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$", max_length=120)
    password: str = Field(min_length=8, max_length=128)


@router.post("/register", status_code=201)
def register(c: Credentials, conn=Depends(get_db)):
    try:
        uid = conn.execute("INSERT INTO users(email,password_hash) VALUES(?,?)",
                           (c.email.lower(), hash_password(c.password))).lastrowid
    except sqlite3.IntegrityError:
        raise HTTPException(409, "An account with this email already exists.")
    return {"token": create_session(conn, uid), "email": c.email.lower()}


@router.post("/login")
def login(c: Credentials, conn=Depends(get_db)):
    u = conn.execute("SELECT * FROM users WHERE email=?", (c.email.lower(),)).fetchone()
    if not u or not verify_password(c.password, u["password_hash"]):
        raise HTTPException(401, "Invalid email or password.")
    return {"token": create_session(conn, u["id"]), "email": u["email"]}


@router.post("/logout", status_code=204)
def logout(token=Depends(bearer), user=Depends(current_user), conn=Depends(get_db)):
    conn.execute("DELETE FROM sessions WHERE token=?", (token,))
    conn.commit()


@router.get("/me")
def me(user=Depends(current_user)):
    return user
